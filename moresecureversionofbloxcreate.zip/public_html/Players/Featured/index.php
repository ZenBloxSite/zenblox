<? include "../../header.php"; ?>
<div class="col s12 m9 l8">
<div class="container" style="width:100%;">
<div class="content-box">
<table>
<tbody>
<tr>
<td width="90%">
<div class="header-text">Featured Users</div>
</td>
<a href="../../Players/" border="0" class="mmbr-usr basic-font">All Users</a>
</tr>
</tbody>
</table>
</div>
<div style="height:25px;"></div><div style="border-bottom:1px solid #DDDDDD;"></div>
<div class="content-box" style="border-radius:0;border:0;border:1px solid #DDDDDD;border-top:0;padding:0 15px;">
<table>
<tbody>
<tr>
<td width="15%" class="center-align">
<center><a href="../../Profile?id=-1"><div style="width:75px;height:75px;border:1px solid #eee;overflow:hidden;" class="circle"><img src="../../Market/Storage/BLOX.png" width="150" style="margin-left:-40px;"></div></a></center>
<a href="#" style="padding-top:5px;display:inline-block;">BLOX Create</a>
</td>
<td width="70%">
<div style="word-break:break-word;">Hello, welcome to BLOX Create, I am the founder of this wonderful establishment. If you need any help, please contact support@bloxcreate.site
</div>
</td>
<td width="15%" class="right-align">
<div style="font-size:12px;color:#666666;">Last Seen 2017</div>
</td>
</tr>
</tbody>
</table>
</div>
<div style="height:25px;"></div><div style="border-bottom:1px solid #DDDDDD;"></div>
<div class="content-box" style="border-radius:0;border:0;border:1px solid #DDDDDD;border-top:0;padding:0 15px;">
<table>
<tbody>
<tr>
<td width="15%" class="center-align">
<center><a href="../../Profile?id=1"><div style="width:75px;height:75px;border:1px solid #eee;overflow:hidden;" class="circle"><img src="../../Market/Storage/Creator.png" width="150" style="margin-left:-40px;"></div></a></center>
<a href="#" style="padding-top:5px;display:inline-block;">Creator</a>
</td>
<td width="70%">
<div style="word-break:break-word;">Hello, I am the founder of this fine establishment! If you need any help, please contact support@bloxcreate.site
</div>
</td>
<td width="15%" class="right-align">
<div style="font-size:12px;color:#666666;">Last Seen 2017</div>
</td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
<? include "../../footer.php"; ?>