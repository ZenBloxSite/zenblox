<?php
$pagename = "New Register";
$pagelink = "http://www.dimensious.com/user/newregister.php";
include('../header.php');
?>
		<div class="rhold">
			<form method="post" class="rform">
				<h1 class="rname basic-font">Register</h1>
				<div class="gender">
					<p class="basic-font q-gender">What is your gender?</p>
					<div class="b-gender a-gender">
						<p class="basic-font b-txt">Boy</p>
						<img src="../images/Avatar.png" />
					</div>
					<div class="g-gender a-gender">
						<p class="basic-font g-txt">Girl</p>
						<img src="../images/Avatar.png" />
					</div>
				</div>
		</div>
<?php
include('../footer.php');
?>