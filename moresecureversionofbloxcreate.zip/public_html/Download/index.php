<html lang="en"><head>
<title>Download Client</title>
<script src="https://storage.googleapis.com/bloxcity-file-storage/assets/js/bundle.js"></script>
<link rel="stylesheet" href="https://storage.googleapis.com/bloxcity-file-storage/assets/css/bc-bundle.css">
<link rel="stylesheet" href="https://www.bloxcity.com/assets/css/default.css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>@import url("https://fonts.googleapis.com/css?family=Source+Sans+Pro:300");body{background:url(http://i.imgur.com/O4OXRfZ.png) no-repeat center center fixed;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;width:100%;height:100%;position:relative;}.light-blue.darken-2,.nav-wrapper,nav{background:transparent!important;}.gen-announcement{font-family:"Source Sans Pro",sans-serif;font-weight:normal;font-size:45px;color:#f1f1f1;padding-bottom:5px;width:100%;text-align:center;}.sub-announcement{font-family:"Source Sans Pro",sans-serif;font-weight:normal;font-size:25px;color:#f1f1f1;padding-bottom:5px;width:100%;text-align:center;}.registration-box{width:75%;}.general-textarea{border:0!important;}@media only screen and (min-width: 993px) {.welcome-header{font-family:"Source Sans Pro",sans-serif;font-weight:300;font-size:45px;color:white;}.major-push{position:absolute;top:50%;transform:translateY(-50%);}}@media only screen and (max-width: 993px) {.welcome-header{font-family:"Source Sans Pro",sans-serif;font-weight:300;font-size:24px;color:white;}.major-push{position:absolute;top:15%;transform:translateY(-15%);text-align:center;margin:0 auto;}.registration-box{margin:0 auto;}}.download-game{display:inline-block;position:relative;cursor:pointer;background:#0CB54D;color:white;font-size:25px;padding:15px 0;width:35%;text-align:center;margin-top:5px;font-weight:600;}.platform-unsupported{cursor:pointer;background:#ababab;color:#363636;font-size:25px;padding:15px 0;width:48%;text-align:center;margin-top:5px;font-weight:600;}.os-info{position:fixed;color:#f1f1f1;bottom:0;right:10px;font-size:18px;}.credits{position:fixed;color:#f1f1f1;bottom:0;left:10px;font-size:18px;}</style>
</head>

<body waid71fa0d88-5390-4b5b-a2f4-e45fa93d85e2="SA password protect entry checker">
<div class="row" style="margin-bottom:0;">
<div class="col s12 m3 l3 hide-on-med-and-down" style="text-align: right;">&nbsp;</div>
<div class="col s12 m9 l6" style="margin-top:5%;">
<div class="gen-announcement">Welcome to <b>BLOX Create</b>.</div>
<div class="sub-announcement" style="margin-bottom:25px;">Download and start building your own creations!</div>
<center><a href="/Games/Play/"><div class="download-game" style="margin-right:15px;">Launch Game</div></a></center>
</div>
<div class="col s12 m3 l3 hide-on-med-and-down" style="text-align: right;">&nbsp;</div>
</div>
<div class="row" style="margin-bottom:0;">
<div class="col s12 m3 l2 hide-on-med-and-down" style="text-align: right;">&nbsp;</div>
<div class="col s12 m9 l8">
<div class="container" style="width:100%;">
</div></div></div><div class="hiddendiv common"></div></body></html>