<html><head>
<style type="text/css">
body {
  margin-top:0 !important;
  padding-top:0 !important;
  min-width:800px !important;
} </style>
<style type="text/css">.cf-hidden { display: none; } .cf-invisible { visibility: hidden; }</style></head><body>
<title>Offline</title>
<style>
			html {
				width: 100%;
				height: 100%;
			}
			body{
				background:#483c76 url('web.archive.org/web/20140420092613im_/https://s3.amazonaws.com/c.meepcity.com/static/offline_bg.png') no-repeat center;
				font-family:Arial,'Helvetica Neue',Helvetica,sans-serif;text-align:center;margin:0;padding:0;border:0; 
				width: 100%;
				height: 100%;
			}
			.title {
				color: #fff;
				font-size: 30px;
				font-weight: bold;
				text-shadow: 0 1px 4px rgba(0,0,0,0.68);
				letter-spacing: -1px;
				margin: 0;
			}
			.logo {
				margin-top: -130px;
			}
		</style>
		<table width="100%" height="100%"><tbody><tr><td align="center">
		
		<div class="title">Offline for Maintenance. We'll be back soon!</div>
		<div class="meep"><img src="http://i.imgur.com/EoGQWTQ.png"></div>
		</td></tr></tbody></table>
</body></html>