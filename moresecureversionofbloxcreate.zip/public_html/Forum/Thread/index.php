<? include "../../header.php"; ?>
<div class="col s12 m9 l8">
<div class="container" style="width:100%;">
<div style="padding:10px 0;font-size:14px;color:#666;">
<div class="row" style="margin:0;">
<div class="col s12 m12 l6">
<a href="#" style="color:#323a45;font-weight:600;">Forum</a> � <a href="#" style="color:#323a45;font-weight:600;">BLOX Create</a> � <a href="#" style="color:#323a45;font-weight:600;">General</a>
</div>
<div class="col s12 m12 l6 right-align">
<a href="#" style="color:#323a45;font-weight:600;">My Threads</a>
&nbsp;|&nbsp;&nbsp;<a href="#" style="color:#323a45;font-weight:600;">Search Forum</a>
</div>
</div>
</div>
<div class="light-blue darken-2" style="color:white;padding:15px 25px;">
<div style="font-size:18px;">.</div>
</div>
<div class="content-box" style="border-top:0;border-radius:0;">
<div class="row">
<div class="col s3 center-align">
<div title="Last seen 5 days ago" style="background:#c2c2c2;width:10px;height:10px;border-radius:10px;display:inline-block;"></div>
&nbsp;<a href="http://bloxcreate.x10.mx/user/profile.php?id=1">.</a>
<a href="http://bloxcreate.x10.mx/user/profile.php?id=1"><img src="http://bloxcreate.x10.mx/Market/Storage/Avatar.png" class="responsive-img"></a>
<div class="row" style="padding-top:15px;font-size:14px;margin-bottom:0;">
<div class="col s3">&nbsp;</div>
<div class="col s3 right-align">
<strong>Posts</strong>
</div>
<div class="col s3 left-align">
1
</div>
</div>
<div class="row" style="font-size:14px;margin-bottom:0;">
<div class="col s3">&nbsp;</div>
<div class="col s3 right-align">
<strong>Joined</strong>
</div>
<div class="col s3 left-align">
2017
</div>
</div>
</div>
<div class="col s9">
<div class="row" style="margin-bottom:0;">
<div class="col s6">
<div style="font-size:14px;color:#777;padding-bottom:10px;">
<i class="material-icons" style="font-size:14px;">access_time</i>
Posted 2 days ago
</div>
</div>
<div class="col s6 right-align">
<a href="#"><div class="report-abuse" style="float:right;">&nbsp;</div></a>
</div>
</div>
<div style="word-break:break-word;">.<br>
<br>
.</div>
</div>
</div>
</div>
</div>
</div>