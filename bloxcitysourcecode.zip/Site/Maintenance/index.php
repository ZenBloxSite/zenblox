<html><head>
<title>Site Offline | BLOX Create</title>
<link rel="stylesheet" href="http://web.archive.org/web/20160929023839cs_/https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.6/css/materialize.min.css">
<link href="http://web.archive.org/web/20160929023839cs_/https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>html,body{background:#F0F0F0;height:100%;width:100%;}</style>
</head>
<body>

<div class="container center-align" style="position:relative;top:40%;transform:translateY(-40%);">
<img src="http://i.imgur.com/VRiFLca.png" class="responsive-img">
<div style="font-size:45px;font-weight:300;">BLOX Create is currently offline.</div>
<div style="font-size:20px;">Our site is offline while we apply a few updates. Please try again later.</div>
</div>
<div class="hiddendiv common"></div></body></html>