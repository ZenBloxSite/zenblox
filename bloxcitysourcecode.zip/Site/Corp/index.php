<html lang="en"><head>
<script type="text/javascript" async="" src="http://web.archive.org/web/20170112095744/https://d31qbv1cthcecs.cloudfront.net/atrk.js"></script><script type="text/javascript" src="/static/js/analytics.js"></script>
<script type="text/javascript">archive_analytics.values.server_name="wwwb-app11.us.archive.org";archive_analytics.values.server_ms=436;</script>
<link type="text/css" rel="stylesheet" href="/static/css/banner-styles.css">
<title>SimpleBuild</title>
<script src="http://web.archive.org/web/20170112095744js_/https://storage.googleapis.com/bloxcity-file-storage/assets/js/bundle.js"></script>
<link rel="stylesheet" href="http://web.archive.org/web/20170112095744cs_/https://storage.googleapis.com/bloxcity-file-storage/assets/css/bc-bundle.css">
<link rel="stylesheet" href="http://web.archive.org/web/20170112095744cs_/https://corp.bloxcity.com/assets/css/main.css">
</head><body><div class="loader" style="display: none;"></div>
<style>body{background:#ededed;}.bc-content{background:#FFF;padding:25px;box-shadow1px 2px #ccc}</style>
<nav style="box-shadow:none;border-bottom: 1px solid #e8e8e8;">
<div class="nav-wrapper" style="background-color:#363636;">
<ul class="right hide-on-med-and-down" style="margin-right:15px;">
<li><a href="/Personal/" style="color:#ffffff;">HOME</a></li>
<li><a href="/Notes/Jobs" style="color:#ffffff;">JOIN THE TEAM</a></li>
<li><a href="/Notes/Contact/" style="color:#ffffff;">CONTACT US</a></li>
</ul>
</div>
<ul class="side-nav" id="mobile-demo" style="background-color:#363636;">
<li><a href="/Personal/" style="color:#ffffff;">HOME</a></li>
<li><a href="/Notes/Jobs" style="color:#ffffff;">JOIN THE TEAM</a></li>
<li><a href="/Notes/Contact/" style="color:#ffffff;">CONTACT US</a></li>
</ul>
<style>@import url('http://web.archive.org/web/20170112095744im_/https://fonts.googleapis.com/css?family=Nunito+Sans:400,600,700');html,body{font-family:'Nunito Sans',sans-serif!important;}.loader{position:fixed;left:0px;top:0px;width:100%;height:100%;z-index:9999;background:url('http://web.archive.org/web/20170112095744im_/https://corp.bloxcity.com/assets/leadership/def_loading.gif') 50% 50% no-repeat rgb(249,249,249);}</style>
<script src="http://web.archive.org/web/20170112095744js_/https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script></nav>
<div style="padding-top:25px;"></div><div class="container" style="width:100%;"></div>
<div style="margin-top:-76px;height:250px;width:100%;background:#127EB3;">
<div style="text-align:center;padding-top:90px;color:white;font-size:44px;">Hello World!</div></div>
<div class="container" style="width:750px;">
<div style="text-align:center;font-weight:600;color:#666666;font-size:36px;">About Us</div>
<div style="padding-top:5px;color:#555555;font-size:18px;">SimpleBuild was founded in January of 2017 by two young entrepreneurs with a dream -- to create a gaming platform that enables users from all over the globe to create and play user created games. With over 5,000 monthly active users, content growth on SimpleBuild continues to increase. To date, 1,000 users join per month on average.</div>
<div style="text-align:center;font-weight:600;color:#666666;font-size:36px;padding-top:50px;">Our Mission</div>
<div style="padding-top:5px;color:#555555;font-size:18px;">Our mission is to encourage young children and adolescents across the globe to create and share 3D content with users alike. Users that sign up are allowed to customize their character, chat with users, create groups, and participate in a marketplace. By enabling creativity within users at a young age, many discover hidden talents within them, such as liking art or coding.</div>
<div style="padding-top:15px;color:#555555;font-size:18px;">As a new company, we are currently focused on website and game development. Our primary goal for 2017 is to release our game client and game workshop, where users can build and script games to their liking. Our games will be available to users on Windows, Mac OS X, and Linux. Additionally, we plan on releasing mobile apps for iOS and Android.</div>
<? include "../../footer.php"; ?>
</div></div><div class="hiddendiv common"></div></body></html>