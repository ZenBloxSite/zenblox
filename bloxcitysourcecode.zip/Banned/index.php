<? include "/header.php"; ?>

<html><head> <title>BloxCity | Home</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="http://materializecss.com/dist/css/materialize.min.css" type="text/css" rel="stylesheet" media="screen,projection">
  <link href="http://materializecss.com/templates/parallax-template/css/style.css" type="text/css" rel="stylesheet" media="screen,projection">
<link href="http://web.archive.org/web/20170112100057cs_/https://www.bloxcity.com/assets/css/default.css" type="text/css" rel="stylesheet" media="screen,projection">

      <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>           
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.3/js/materialize.min.js"></script> 

<script src='https://www.google.com/recaptcha/api.js'></script>

<style>
body {
    background-color: #eceff1;
}
</style>

<script>
$('.dropdown-button').dropdown({
      inDuration: 300,
      outDuration: 225,
      constrainWidth: true, // Does not change width of dropdown to that of the activator
      hover: false, // Activate on hover
      gutter: 0, // Spacing from edge
      belowOrigin: true, // Displays dropdown below the button
      alignment: 'right', // Displays dropdown with edge aligned to the left of button
      stopPropagation: false // Stops event propagation
    }
  );
</script>

<nav <? if ($user){ ?> style="" <? } ?> class="main-nav">
<div class="nav-wrapper light-blue darken-2">
<a href="/" class="brand-logo">
<div style="margin-top:10px;margin-left:10px;height:40px;width:40px;background:white;" class="circle">
<img src="https://i.imgur.com/UBiGSWl.png" style="margin-top:-1px;height:42px;width:42px;padding: 8px 8px;">
</div>
</a>
<ul class="left hide-on-med-and-down" style="margin-left:65px;">
<li><a href="/">Home</a></li>
<li><a href="/Games">Games</a></li>
<li><a href="/Market">Market</a></li>
<li><a href="/Groups">Groups</a></li>

<li><a href="/Forum">Forum</a></li>
<li><a href="/Upgrade">Upgrade</a></li>
<li><a href="/Players">Users</a></li>

<li class="no-hover"><a class="dropdown-button2" href="#" data-activates="more-links"><i class="material-icons" style="font-size:16px;">arrow_drop_down</i></a><ul id="more-links" class="dropdown-content">

<li><a href="/Personal/Messages">Inbox</a></li>
    <li><a href="/Profile/?username=<? echo $myu->username ?>">Profile</a></li>
	    <li><a href="/Customize">Customize</a></li>

    <li><a href="/user/logout.php">Logout</a></li>
</ul></li>
</ul>

<ul class="right hide-on-med-and-down">
<script>
						$(document).ready(function(){
							$('.tooltipped').tooltip({delay: 50});
							$(".dropdown-button2").dropdown({belowOrigin: true});
						});
					</script>
<? if (!$user){ ?>
<li><a href="/"></a></li>
<li><a href="/"></a></li><? } ?></ul>
</div>
</nav>

<div style="width:1100px;" class="container">

<div style="padding-top:35px;"></div>
<? if ($user){?><div style="; width:1285px;" class="container"><? } else {?>
<div style="width:1300px;" class="container"><? } ?>

<? if ($user){?><ul id="nav-mobile" class="side-nav fixed" style="width:175px transform: translateX(0%);">

<li><div class="user-view">
      <div class="background">

      </ul><? } ?>
<div style="padding-top:50px;"></div>
<div class="card-panel light-blue darken-2 white-text"><center><table style="padding:0;margin:0;"><tbody><tr></tr></tbody></table>Join our discord! https://discord.gg/GJ7xf3J</center></div>

<div class="col s12 m9 l8">
<div class="container" style="width:100%;">
<style>.susp-spacer{margin-top:10px;border-top:1px solid #efefef;padding-bottom:10px;}</style>
<div class="row">
<div class="col s12 m12 l2">&nbsp;</div>
<div class="col s12 m12 l8">
<div class="content-box">
<h5 style="font-weight:600;text-transform:uppercase">YOUR ACCOUNT HAS BEEN BANNED</h5>
<div class="susp-spacer" style="border:0;"></div>
Your account was terminated for violating our <a href="/Notes/Terms">terms of service</a>.<div style="padding-top:10px;"></div>
Below is information associated with this termination. If you have questions, concerns, or comments related to this termination, we advise that you contact our support department.
<div class="susp-spacer" style="margin-bottom:10px;margin-top:15px;"></div>
<div class="row">
<div class="col s12 m12 l2 right-align">
<b>Banned By:</b>
</div>
<div class="col s12 m12 l10">SimpleBuild
</div>
</div><div class="row">
<form action="" method="POST" style="margin:0;padding:0;">
<center>
Your account has been banned. Thank you for playing!
<div style="color:gray;margin-top:10px;font-size:13px;">
<div class="center-align"><li><a href="/user/logout.php">Logout</a></li> 
</div>
</div>
</center>
</form>
</div>
</div>
<div class="col s12 m12 l2">&nbsp;</div>
</div>
</div>
</div></body></html>
<? include "/footer.php"; ?>
