<? include "../header.php";
$items = $handler->query("SELECT * FROM items ORDER BY id DESC");
?>
<div class="bc-content">
<div class="right-align">
<a class="btn-floating btn-large waves-effect waves-light red" style="float:right;margin-top:-35px;margin-right:-35px;position:absolute;" href="#"><i class="material-icons">add</i></a>
</div>
<div class="row">
<div class="col s2">
<h4 style="padding-bottom:20px;">Market</h4>
</div>
</div>
<div class="row">

<div class="col s12 m12 l10">
<div class="row">
<div id="market-col" class="col s12 m12 l2 center-align">
<a href="/web/20170104013652/https://www.bloxcity.com/market/55464/" title="New Year's Grin" alt="New Year's Grin">
<div style="position:relative;">
<img id="1" src="http://i.imgur.com/PYWa4Pq.png" style="width:100%;border:1px solid #eee;" class="market-item">
</div>
</a>
<a href="/web/20170104013652/https://www.bloxcity.com/market/55464/" style="display:block;padding:2px 0;color:#333;font-weight:500;" title="New Year's Grin" alt="New Year's Grin">New Year's Grin</a>
<div style="color:#666;font-size:12px;">Creator: <a href="#">Creator</a></div>
<font style="color:#F7D358;font-size:12px;">0 Coins</font>
<div style="height:25px;"></div>
</div>
<div class="clearfix"></div>
</div>
</div>
</div>

</div>