<?php

?>
<html>
<head>
</head>
</body>
</div>
<div class="footer-push"></div>
</div>
<style>.site-footer a:hover{color:#AAAAAA!important;}</style>
<div class="site-footer center-align">
<div style="padding-top:28px;color:white;">
<div style="clear:none;padding:0 15px;display:inline-block;"><a href="/Notes/Terms" style="color:#757575;">TERMS</a></div>
<div style="clear:none;padding:0 15px;display:inline-block;"><a href="/Notes/Privacy" style="color:#757575;">PRIVACY</a></div>
<div style="clear:none;padding:0 15px;display:inline-block;"><a href="http://web.archive.org/web/20170213184902/http://help.bloxcity.com/" style="color:#757575;">SUPPORT</a></div>
<div style="clear:none;padding:0 15px;display:inline-block;"><a href="#" style="color:#757575;">ABOUT</a></div>
<div style="clear:none;padding:0 15px;display:inline-block;"><a href="/Notes/Jobs/" style="color:#757575;">JOBS</a></div>
<div style="clear:none;padding:0 15px;display:inline-block;"><a href="https://discordapp.com/users/582944943568584714/" style="color:#757575;">Credit</a></div>
<div style="clear:none;padding:0 15px;display:inline-block;"><a href="/Notes/Contact/" style="color:#757575;">CONTACT</a></div>
<div style="padding-top:15px;padding-bottom:15px;color:#999999;font-size:14px;">&copy;2017 BLOX City, Inc.</div>
<div style="clear:none;padding:0 2px;display:inline-block;"><a href="" target="_blank"><img src="http://web.archive.org/web/20170213184902im_/https://storage.googleapis.com/bloxcity-file-storage/assets/images/facebook.png" style="height:25px;"></a></div>
<div style="clear:none;padding:0 2px;display:inline-block;"><a href="" target="_blank"><img src="http://web.archive.org/web/20170213184902im_/https://storage.googleapis.com/bloxcity-file-storage/assets/images/twitter.png" style="height:25px;"></a></div>
</div>
</div>
</body>
</html>