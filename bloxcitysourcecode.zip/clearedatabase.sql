-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql302.byetcluster.com
-- Generation Time: May 30, 2021 at 06:12 PM
-- Server version: 5.6.48-88.0
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hp_28747590_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `alphakeys`
--

CREATE TABLE `alphakeys` (
  `email` longtext NOT NULL,
  `code` longtext NOT NULL,
  `ip` longtext NOT NULL,
  `redeemed` int(11) NOT NULL DEFAULT '0',
  `active` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE `banner` (
  `text` longtext NOT NULL,
  `link` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `title`, `content`) VALUES
(1, 'Welcome to SimpleBuild', 'Normal operations will begin shortly. We are currently working on setting up a business hotline.'),
(1, 'Welcome to SimpleBuild', 'Normal operations will begin shortly. We are currently working on setting up a business hotline.');

-- --------------------------------------------------------

--
-- Table structure for table `configuration`
--

CREATE TABLE `configuration` (
  `SiteName` text COLLATE utf8_unicode_ci NOT NULL,
  `GameURL` text COLLATE utf8_unicode_ci NOT NULL,
  `Image` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `games`
--

CREATE TABLE `games` (
  `id` int(11) NOT NULL,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `owner` text COLLATE utf8_unicode_ci NOT NULL,
  `visits` int(11) NOT NULL,
  `favorites` int(11) NOT NULL,
  `Created` text COLLATE utf8_unicode_ci NOT NULL,
  `playing` int(11) NOT NULL,
  `image` text COLLATE utf8_unicode_ci NOT NULL,
  `play` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `games`
--

INSERT INTO `games` (`id`, `title`, `description`, `owner`, `visits`, `favorites`, `Created`, `playing`, `image`, `play`) VALUES
(1, 'Crates', 'just a baseplate with a simple crate\r\n', 'BrickCreate', 312, 7, 'Jan 23rd 2017\r\n', 3, 'https://i.imgur.com/Kq7AKvX.png', '1/'),
(2, 'Particle Testing', 'Testing a bit of particles', 'BrickCreate', 129, 7, 'Feb 2nd, 2018', 2, 'https://i.imgur.com/mjAAb5T.png', '2/');

-- --------------------------------------------------------

--
-- Table structure for table `groupmembers`
--

CREATE TABLE `groupmembers` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `groupid` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `groupmembers`
--

INSERT INTO `groupmembers` (`id`, `userid`, `groupid`, `status`) VALUES
(0, 1, 1, 1),
(0, 302, 1, 1),
(0, 305, 1, 1),
(0, 288, 1, 1),
(0, 313, 1, 1),
(0, 325, 1, 1),
(0, 326, 1, 1),
(0, 322, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` int(11) NOT NULL,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `vault` text COLLATE utf8_unicode_ci NOT NULL,
  `members` int(11) NOT NULL,
  `owner` text COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `image` text COLLATE utf8_unicode_ci NOT NULL,
  `private` varchar(8) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'false'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `title`, `vault`, `members`, `owner`, `description`, `image`, `private`) VALUES
(1, 'AvatarSquare', '21418', 5, 'AvatarSquare', 'Open to all members, not just admins!', 'https://i.imgur.com/UBiGSWl.png', 'false');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `item` int(11) NOT NULL,
  `user` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`item`, `user`) VALUES
(1, 336),
(1, 1),
(1, 275),
(2, 336),
(1, 278),
(1, 278),
(1, 281),
(1, 282),
(1, 283),
(2, 1),
(1, 285),
(1, 287),
(1, 286),
(1, 287),
(2, 286),
(2, 288),
(1, 288),
(2, 289),
(1, 291),
(1, 296),
(3, 1),
(1, 300),
(3, 302),
(2, 302),
(1, 302),
(1, 305),
(2, 308),
(1, 308),
(1, 307),
(2, 308),
(3, 106),
(1, 313),
(2, 313),
(4, 1),
(1, 323),
(2, 326),
(4, 327),
(7, 1),
(6, 1),
(5, 1),
(4, 330),
(1, 332),
(1, 335),
(2, 322),
(4, 322),
(22, 326),
(22, 326),
(1, 326),
(6, 326),
(5, 326),
(2, 326),
(22, 326),
(22, 326),
(8, 1),
(4, 336),
(9, 1),
(9, 326),
(8, 326);

-- --------------------------------------------------------

--
-- Table structure for table `ipbans`
--

CREATE TABLE `ipbans` (
  `ip` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `iplogs`
--

CREATE TABLE `iplogs` (
  `ip` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `iplogs`
--

INSERT INTO `iplogs` (`ip`) VALUES
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('70.42.131.170'),
('70.42.131.170'),
('52.55.124.222'),
('66.249.64.17'),
('66.249.64.16'),
('66.249.64.17'),
('66.249.64.17'),
('66.249.64.17'),
('66.249.64.18'),
('66.249.64.17'),
('165.161.3.53'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('66.249.93.18'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('185.79.93.76'),
('185.79.93.76'),
('185.79.93.76'),
('185.79.93.76'),
('185.79.93.76'),
('185.79.93.76'),
('185.79.93.76'),
('49.191.33.215'),
('49.191.33.215'),
('73.136.88.144'),
('73.136.88.144'),
('73.136.88.144'),
('73.136.88.144'),
('73.136.88.144'),
('73.136.88.144'),
('73.136.88.144'),
('73.136.88.144'),
('73.136.88.144'),
('73.136.88.144'),
('73.136.88.144'),
('73.136.88.144'),
('73.136.88.144'),
('73.136.88.144'),
('73.136.88.144'),
('73.136.88.144'),
('73.136.88.144'),
('73.136.88.144'),
('73.136.88.144'),
('73.136.88.144'),
('73.136.88.144'),
('73.136.88.144'),
('73.136.88.144'),
('73.136.88.144'),
('104.218.62.3'),
('104.218.62.3'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('75.132.19.99'),
('66.249.64.16'),
('66.249.64.18'),
('66.249.64.16'),
('66.249.64.17'),
('66.249.64.16'),
('66.249.64.17'),
('66.249.64.17'),
('66.249.64.18'),
('66.249.64.16'),
('66.249.64.18'),
('66.249.64.18'),
('66.249.64.18'),
('86.165.93.173'),
('86.165.93.173'),
('86.165.93.173'),
('86.165.93.173'),
('86.165.93.173'),
('86.165.93.173'),
('86.165.93.173'),
('86.165.93.173'),
('86.165.93.173'),
('86.165.93.173'),
('86.165.93.173'),
('86.165.93.173'),
('86.165.93.173'),
('86.165.93.173'),
('86.165.93.173'),
('86.165.93.173'),
('86.165.93.173'),
('86.165.93.173'),
('86.165.93.173'),
('83.249.230.211'),
('83.249.230.211'),
('83.249.230.211'),
('83.249.230.211'),
('83.249.230.211'),
('83.249.230.211'),
('83.249.230.211'),
('83.249.230.211'),
('83.249.230.211'),
('83.249.230.211'),
('83.249.230.211'),
('83.249.230.211'),
('83.249.230.211'),
('83.249.230.211'),
('83.249.230.211'),
('83.249.230.211'),
('83.249.230.211'),
('83.249.230.211'),
('83.249.230.211'),
('83.249.230.211'),
('83.249.230.211'),
('83.249.230.211'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('66.249.64.18'),
('66.249.64.19'),
('66.249.93.19'),
('66.249.93.19'),
('66.249.64.18'),
('66.249.64.19'),
('62.112.9.166'),
('62.112.9.166'),
('62.112.9.166'),
('62.112.9.166'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('66.249.93.18'),
('66.249.93.17'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('66.249.64.18'),
('66.249.64.17'),
('66.249.64.17'),
('66.249.64.16'),
('23.127.208.78'),
('23.127.208.78'),
('23.127.208.78'),
('23.127.208.78'),
('23.127.208.78'),
('23.127.208.78'),
('23.127.208.78'),
('23.127.208.78'),
('23.127.208.78'),
('86.168.139.31'),
('86.168.139.31'),
('86.168.139.31'),
('86.168.139.31'),
('86.168.139.31'),
('86.168.139.31'),
('86.168.139.31'),
('86.168.139.31'),
('86.168.139.31'),
('86.168.139.31'),
('86.168.139.31'),
('86.168.139.31'),
('66.249.93.17'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('73.1.145.75'),
('66.249.64.16'),
('66.249.64.17'),
('86.165.93.173'),
('86.165.93.173'),
('86.165.93.173'),
('174.206.3.252'),
('174.206.3.252'),
('174.206.3.252'),
('174.206.3.252'),
('174.206.3.252'),
('174.206.3.252'),
('109.90.223.128'),
('109.90.223.128'),
('109.90.223.128'),
('109.90.223.128'),
('109.90.223.128'),
('109.90.223.128'),
('109.90.223.128'),
('109.90.223.128'),
('109.90.223.128'),
('109.90.223.128'),
('109.90.223.128'),
('109.90.223.128'),
('109.90.223.128'),
('109.90.223.128'),
('109.90.223.128'),
('109.90.223.128'),
('109.90.223.128'),
('109.90.223.128'),
('109.90.223.128'),
('109.90.223.128'),
('190.2.131.205'),
('190.2.131.205');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `type` text NOT NULL,
  `image` text NOT NULL,
  `creator` text NOT NULL,
  `created` text NOT NULL,
  `wearable` text NOT NULL,
  `price` int(11) NOT NULL,
  `onsale` int(11) NOT NULL DEFAULT '1',
  `collectable` varchar(32) NOT NULL DEFAULT 'false',
  `amount` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `name`, `description`, `type`, `image`, `creator`, `created`, `wearable`, `price`, `onsale`, `collectable`, `amount`) VALUES
(1, 'Top Hat', 'Simple hat for a Brick Creator', 'accessory', 'https://i.imgur.com/cVeUhjk.png', 'AvatarSquare', 'Jan 23rd 2018', 'top.png', 5, 1, 'false', -1),
(2, 'Recycling Bin', 'Reduce reuse and recycle', 'accessory', 'https://i.imgur.com/Y2n9hRv.png', 'AvatarSquare\r\n', 'Jan 25th, 2002', 'recycle.png', 10, 1, 'false', -1),
(3, 'Ice Cream', 'Perhaps its most unique characteristic is its ability to inspire viewers with awe while at the same time making the wearer look goofy.', 'accessory', 'https://i.imgur.com/ZCpOrIL.png', 'AvatarSquare', 'Jan 25th, 2002', 'Icecream.png', 35, 1, 'true', 2),
(4, 'Man Hair', 'Gorgeous hair for gorgeous people!', 'accessory', 'https://i.imgur.com/NXX7De4.png', 'AvatarSquare\r\n', 'Jan 28th, 2018', 'hairr.png', 5, 1, 'false', -1),
(5, 'Bucket Hat', 'It\'s stylish and provides you with 360 degrees of UV Sun ray protection!', 'accessory', 'https://i.imgur.com/dYRtldi.png', 'AvatarSquare', 'Feb 3rd, 2018', 'bucket.png', 65, 1, 'false', -1),
(6, 'Hammer', 'The Hammer will only listen to those whom are worthy', 'body', 'https://i.imgur.com/kzSgHPJ.png', 'AvatarSquare', 'Feb 3rd, 2018', 'hammer.png', 185, 1, 'false', -1),
(7, 'Blonde Man', 'Who says you can\'t play the part? With this hair no one will be able to tell that you stuck that whoopee cushion under your coworker\'s chair.', 'accessory', 'https://i.imgur.com/hKjT5j0.png', 'AvatarSquare', 'Feb 3rd, 2018', 'jbhair.png', 15, 1, 'false', -1),
(9, 'Diver', 'Who lives in a pineapple under the sea?', 'accessory', 'https://i.imgur.com/tL8nENT.png', 'AvatarSquare', 'Feb 11th, 2018', 'diverwear.png', 30, 1, 'false', -1),
(8, 'Steel King', 'The classic shape in classic material. Classic!', 'accessory', 'https://i.imgur.com/mjMbrJ4.png', 'AvatarSquare', 'Feb 10th, 2018', 'darksteel.png', 75, 1, 'false', -1);

-- --------------------------------------------------------

--
-- Table structure for table `lottery`
--

CREATE TABLE `lottery` (
  `username` text NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `sender` int(11) NOT NULL,
  `receiver` int(11) NOT NULL,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`sender`, `receiver`, `title`, `message`) VALUES
(21, 1, 'hi', 'yo bro i got banned from the discord for no reason ;(( i asked a simple question'),
(97, 1, 'lol', 'lol'),
(107, 105, '12', '20'),
(283, 283, 'f', 'f'),
(0, 283, 'test', 'test'),
(287, 287, 'hi me', 'how are you doing'),
(307, 308, '<a href=\"https://www.youtube.com/SkateAlert\">THE BEST YOUTUBER EVER</a>', '<a href=\"https://www.youtube.com/SkateAlert\">THE BEST YOUTUBER EVER</a>'),
(307, 308, '<img src=\"http://i1.ytimg.com/vi/IA5yUXVIcHA/hqdefault.jpg\" alt=\"hi\"> ', '<img src=\"http://i1.ytimg.com/vi/IA5yUXVIcHA/hqdefault.jpg\" alt=\"hi\"> '),
(307, 326, '<script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script>', '<script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script> <script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script> <script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script> <script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script> <script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script> <script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script>'),
(307, 308, '<script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script>', '<script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script><script>alert(\"#Hacked by Team Nice. YouTube - https://www.youtube.com/SkateAlert Website: https://skatealert.xyz\")</script>'),
(286, 106, 'hi', 'ugly'),
(315, 315, '<script>alert(\"hey fix this xss\")</script>', '<script>alert(\"hey fix this xss\")</script>'),
(329, 1, 'I would love to be an administrator', 'My discord is iVarialChase#2564 add me please!'),
(326, 1, 'Testing', 'Testing'),
(326, 1, 'Hi send me back something', 'Reply'),
(326, 326, 'Hi', 'papapapaa'),
(0, 326, 'saaaaaaaaaaaaaaaaaa', 'asssssssssssssssss'),
(0, 326, 'sadsadsa', 'sadsadsa'),
(326, 326, 'aaaa', 'aaaaaaaaaa'),
(326, 326, '2', '2');

-- --------------------------------------------------------

--
-- Table structure for table `refurbishment`
--

CREATE TABLE `refurbishment` (
  `status` text COLLATE utf8_unicode_ci NOT NULL,
  `end` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `refurbishment`
--

INSERT INTO `refurbishment` (`status`, `end`) VALUES
('true', '7/29/2017');

-- --------------------------------------------------------

--
-- Table structure for table `replies`
--

CREATE TABLE `replies` (
  `threadId` int(11) NOT NULL,
  `postBy` text NOT NULL,
  `postText` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `replies`
--

INSERT INTO `replies` (`threadId`, `postBy`, `postText`) VALUES
(39, 'test', 'Me pls'),
(36, 'Wow', 'This is a clear copy..'),
(54, 'MegaDrive', 'brick planet remake thingy'),
(54, 'Wow', 'This isnt even needed and is pretty much clearly copied'),
(54, 'Warlord', 'i think this is the start of blox city, we went back in time bois'),
(56, 'Wow', 'me too'),
(56, 'Wow', 'me too'),
(56, 'Warlord', ''),
(74, 'niceguy1000', 'yessssss'),
(2, 'drifttwo', '<script>alert(\"subscribe to SkateAlert on YouTube\")</script>'),
(2, 'drifttwo', 'I used his same xss and it still works...'),
(3, 'drifttwo', '<script>alert(\"Please fix this xss.\")</script>'),
(2, 'ihascancer', 'Yesh, Im mlg'),
(6, 'niceguy1000', 'lol'),
(13, 'Babyhamsta', 'testr');

-- --------------------------------------------------------

--
-- Table structure for table `threads`
--

CREATE TABLE `threads` (
  `topicId` int(11) NOT NULL DEFAULT '1',
  `threadId` int(11) NOT NULL,
  `threadAdmin` text NOT NULL,
  `threadTitle` varchar(128) NOT NULL,
  `threadBody` varchar(1024) NOT NULL,
  `views` int(11) NOT NULL,
  `replies` int(11) NOT NULL,
  `pinned` varchar(32) NOT NULL DEFAULT 'false'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `topics`
--

CREATE TABLE `topics` (
  `id` int(11) NOT NULL,
  `threads` int(11) NOT NULL,
  `replies` int(11) NOT NULL,
  `name` varchar(512) NOT NULL,
  `description` varchar(512) NOT NULL,
  `lastPostTitle` varchar(512) NOT NULL,
  `lastPostBy` varchar(512) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `topics`
--

INSERT INTO `topics` (`id`, `threads`, `replies`, `name`, `description`, `lastPostTitle`, `lastPostBy`) VALUES
(1, 0, 0, 'General Discussion', 'General information regarding anything throughout the website should be posted here!', 'Thread', 'Username');

-- --------------------------------------------------------

--
-- Table structure for table `updates`
--

CREATE TABLE `updates` (
  `id` int(11) NOT NULL,
  `description` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `userips`
--

CREATE TABLE `userips` (
  `id` int(11) NOT NULL,
  `ip` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userips`
--

INSERT INTO `userips` (`id`, `ip`) VALUES
(1, '73.1.145.75'),
(0, '73.1.145.75'),
(1, '172.58.169.15'),
(275, '81.141.179.195'),
(277, '205.215.175.102'),
(278, '205.215.175.102'),
(281, '73.141.196.47'),
(1, '165.161.15.54'),
(282, '129.161.80.16'),
(106, '82.4.137.136'),
(283, '12.91.232.66'),
(284, '82.4.137.136'),
(286, '68.34.80.253'),
(285, '158.248.233.54'),
(287, '5.142.128.202'),
(288, '186.212.234.143'),
(289, '73.1.145.75'),
(291, '80.234.181.130'),
(292, '68.51.176.172'),
(288, '177.205.151.138'),
(296, '24.146.166.122'),
(293, '68.37.53.93'),
(299, '79.160.18.14'),
(300, '68.116.192.161'),
(301, '98.161.55.211'),
(302, '76.189.147.102'),
(304, '68.144.198.156'),
(275, '86.160.130.29'),
(285, '185.59.105.251'),
(305, '141.237.182.30'),
(307, '62.231.136.5'),
(308, '62.231.136.5'),
(309, '12.91.232.66'),
(288, '179.186.30.149'),
(288, '187.59.166.67'),
(310, '71.17.169.156'),
(311, '92.25.189.122'),
(288, '179.177.162.252'),
(312, '24.146.166.122'),
(313, '98.121.115.91'),
(314, '109.152.91.109'),
(315, '142.59.152.131'),
(318, '62.231.136.5'),
(320, '62.231.136.5'),
(321, '91.10.39.165'),
(322, '62.231.136.5'),
(323, '79.116.206.224'),
(325, '68.149.244.125'),
(326, 'Nahfam -Bham cleared'),
(327, '70.166.212.162'),
(329, '70.190.177.60'),
(309, '75.132.19.99'),
(330, '5.68.0.70'),
(331, '109.150.131.119'),
(332, '86.183.180.50'),
(335, '62.231.136.5'),
(1, '165.161.15.38'),
(336, '73.1.145.75');

-- --------------------------------------------------------

--
-- Table structure for table `userposts`
--

CREATE TABLE `userposts` (
  `id` int(11) NOT NULL,
  `poster` text COLLATE utf8_unicode_ci NOT NULL,
  `posted` int(11) NOT NULL,
  `img` text COLLATE utf8_unicode_ci NOT NULL,
  `status` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` longtext NOT NULL,
  `password` longtext NOT NULL,
  `email` longtext NOT NULL,
  `ip` longtext NOT NULL,
  `datecreated` longtext NOT NULL,
  `verified` int(11) NOT NULL DEFAULT '0',
  `banned` int(11) NOT NULL DEFAULT '0',
  `reason` text NOT NULL,
  `emeralds` varchar(2048) NOT NULL DEFAULT '50',
  `getemeralds` int(11) NOT NULL,
  `trades` int(11) NOT NULL,
  `requests` int(11) NOT NULL,
  `messages` int(11) NOT NULL DEFAULT '1',
  `elite` int(11) NOT NULL DEFAULT '0',
  `eliteexpire` longtext NOT NULL,
  `admin` varchar(32) NOT NULL DEFAULT 'false',
  `bouncer` varchar(32) NOT NULL DEFAULT 'false',
  `designer` varchar(32) NOT NULL DEFAULT 'false',
  `visittick` longtext NOT NULL,
  `expiretime` longtext NOT NULL,
  `description` text NOT NULL,
  `package` varchar(32) NOT NULL DEFAULT 'Avatar.png',
  `accessory` text NOT NULL,
  `badge` text NOT NULL,
  `outfit` text NOT NULL,
  `face` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `games`
--
ALTER TABLE `games`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groupmembers`
--
ALTER TABLE `groupmembers`
  ADD UNIQUE KEY `userid` (`userid`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lottery`
--
ALTER TABLE `lottery`
  ADD UNIQUE KEY `userid` (`userid`);

--
-- Indexes for table `threads`
--
ALTER TABLE `threads`
  ADD PRIMARY KEY (`threadId`),
  ADD UNIQUE KEY `threadId` (`threadId`);

--
-- Indexes for table `topics`
--
ALTER TABLE `topics`
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `updates`
--
ALTER TABLE `updates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userposts`
--
ALTER TABLE `userposts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `threads`
--
ALTER TABLE `threads`
  MODIFY `threadId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `updates`
--
ALTER TABLE `updates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=337;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
