<? include "../../../header.php"; ?>
<div class="col s12 m9 l8">
<div class="container" style="width:100%;">
<script>
			document.title = "Messages | BLOXCreate";
		</script></center>
<div style="padding:10px 4px;font-size:14px;color:#666;">
<a href="#" style="color:#323a45;font-weight:600;">Dashboard</a> » <a href="#" style="color:#323a45;font-weight:600;">Inbox</a> » <a href="#" style="color:#323a45;font-weight:600;">I just joined BloxCreate</a>
</div>
<div class="bc-content">
<div class="row" style="margin-bottom:0;">
<div class="col s12 m6 l2 center-align">
<a href="#">
<div style="width:100px;height:100px;border:1px solid #dedede;margin:0 auto;overflow:hidden;" class="circle center-align">
<img src="http://bloxcreate.site/Market/Storage/a1f3fc6ece4db4e43e529c74efed65da588c0741947d9.png" width="200" height="200" style="margin-left:-50px;">
</div>
</a>
<a href="http://bloxcreate.site/Profile/?id=1" style="display:block;font-size:14px;">Creator</a>
</div>
<div class="col s12 m6 l10">
<div class="row" style="margin-bottom:0;">
<div class="col s10">
<div style="word-wrap:break-word;font-size:24px;">I just joined BloxCreate!</div>
</div>
<div class="col s2 right-align">
</div>
</div>
<div style="font-size:12px;color:#888888;">Received 1 day ago</div>
<div style="height:10px;"></div>
<div style="border-top:1px solid #eee;"></div>
<div style="height:10px;"></div>
<div style="word-wrap:break-word;font-size:14px;">Hello Nicholas, I've just joined BloxCreate! I agree to any terms and conditions and subject myself to any punishment nessicary if they shall be broken at any point in time!</div>
</div>
</div>
</div>
</div>
</div>
<? include "../../../footer.php"; ?>