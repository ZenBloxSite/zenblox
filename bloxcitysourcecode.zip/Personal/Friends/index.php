<? include "../../header.php"; ?>
<div class="bc-content">
<div class="header-text" style="padding-bottom:15px;">Pending Friend Requests</div><div style="font-size:14px;">You have no pending friend requests at this time.</div></div>