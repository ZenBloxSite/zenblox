<? include "../../header.php"; ?>
<div class="col s12 m9 l8">
<div class="container" style="width:100%;">
<script>
		document.title = "Achievements | BLOX Create";
	</script>
<div class="row">
<h5 style="padding-bottom:10px;">Special Achievements</h5>
<div class="col s6">
<div class="content-box" style="padding:0px;margin-bottom:10px;">
<div style="padding:20px;">
<div style="vertical-align:top;width:100px;height:100px;display:inline-block;background-image:url(http://i.imgur.com/sXzWkAn.png);background-size:100px 100px;"></div>
<div style="width:20px;display:inline-block;"></div>
<div style="display:inline-block;vertical-align:top;width:70%;">
<font style="font-size:20px;font-weight:500;">Administator</font>
<br>
Players who possess this achievement are BLOX Create administrators. Administrators are members of BLOX Create staff who oversee the website and keep it running smoothly.
</div>
</div>
</div>
</div>
<div class="col s6">
<div class="content-box" style="padding:0px;margin-bottom:10px;">
<div style="padding:20px;">
<div style="vertical-align:top;width:100px;height:100px;display:inline-block;background-image:url(http://i.imgur.com/wYGeTaS.png);background-size:100px 100px;"></div>
<div style="width:20px;display:inline-block;"></div>
<div style="display:inline-block;vertical-align:top;width:70%;">
<font style="font-size:20px;font-weight:500;">Rich</font>
<br>Players who possess this achievement have at least 500 coins. When a user has this achievement, you can rest assured that they are the richest of the rich! If at any time your coins drop below 500 coins, this will be removed from your account!
</div>
</div>
</div>
</div>
<div class="col s6">
<div class="content-box" style="padding:0px;margin-bottom:10px;">
<div style="padding:20px;">
<div style="vertical-align:top;width:100px;height:100px;display:inline-block;background-image:url(http://i.imgur.com/Q4U7qpO.png);background-size:100px 100px;"></div>
<div style="width:20px;display:inline-block;"></div>
<div style="display:inline-block;vertical-align:top;width:70%;">
<font style="font-size:20px;font-weight:500;">Elite User</font>
<br>Those who possess this achievement have a current elite membership. There are 4 different memberships going from two dollars to eighteen dollars. If you wish to posess this achievement, upgrade your account.
</div>
</div>
</div>
</div>
<div class="col s6">
<div class="content-box" style="padding:0px;margin-bottom:10px;">
<div style="padding:20px;">
<div style="vertical-align:top;width:100px;height:100px;display:inline-block;background-image:url(http://i.imgur.com/CBSutwt.png);background-size:100px 100px;"></div>
<div style="width:20px;display:inline-block;"></div>
<div style="display:inline-block;vertical-align:top;width:70%;">
<font style="font-size:20px;font-weight:500;">Verified Player</font>
<br>Players who possess this achievement are known by administrators for their helpfulness in the community. This achievement is only obtainable if a bug is reported by the player or the administrators feel the player deserves this badge for their helpfullness.
</div>
</div>
</div>
</div>


<div class="col-md-1"></div>
</div>


</div>
</div>
<? include "../../footer.php"; ?>