<? include "../../header.php"; ?>
<h5>Terms of Service</h5>
<div style="font-size:13px;padding:5px;border-top:1px solid #eee;margin-top:20px;"></div>
<font class="welcome-txt">
<p>Welcome to our website, a massive user generated content platform where users can create games, clothing, forum with users, and more!</p>
<p>By using our site, you agree to these terms of service. Please read the following terms carefully. By accessing our web site(s) or services, you hereby agree to be bound by these terms and all terms incorporated herein by reference. It is the responsibility of you, the user or parent/guardian to read the terms of service before proceeding to use our web site or services. If you do not agree to our terms, do not use our web site or services. This document is effective as of <font style="font-weight:bold;">January 21, 2017</font>.</p>
</font>
<? include "../../footer.php"; ?>