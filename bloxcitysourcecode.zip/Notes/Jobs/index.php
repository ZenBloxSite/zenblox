<? include "../../header.php"; ?>
<div class="container" style="width:100%;">
<div class="row">
<div class="bc-content">
<h4>Jobs</h4>
<div class="initial-divider"></div>
<div style="color:#666666;font-weight:bold;font-size:14px;">WHERE TO APPLY</div>
For corporation job related inquiries, such as reporting or applying for a position, please email support. Please allow our support staff 24-48 hours to respond to your email. You will be automatically emailed a unique ticket number. Please keep this ticket number handy if you are emailing us about past tickets. Additionally you may contact us via phone at <b>Coming Soon</b> to speak to a support agent. If no support agents are available, you will be asked to leave some information so that we may contact you back.
<div style="margin-top:25px;"></div>
<div style="color:#666666;font-weight:bold;font-size:14px;">REQUIREMENTS</div>Please provide your age, date of birth, legal name, resume, and a phone number for us to contact and what position you're applying for!

Once providing the following given above, please describe your skill set and who you are as a person in no less than 500 words.
Your application will not be considered unless 500 words is provided. You will send this information to our support email!</div>
<div style="padding-top:10px;"></div>
<font style="float:right;"><a href="/">Return</a></font>
</div>
&#65279;		</div>
<? include "../../footer.php"; ?>