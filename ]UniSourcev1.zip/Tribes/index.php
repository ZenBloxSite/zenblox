<title>Unitorium</title>
<link rel="icon" href="https://cdn.discordapp.com/attachments/741437141057273927/786340710080184320/UNITORIUM.png" type="image/x-icon"/>

<script language="JavaScript">					
TargetDate = "2/15/2021 12:00 AM";
BackColor = "palegreen";
ForeColor = "navy";
CountActive = true;
CountStepper = -1;
LeadingZero = true;
DisplayFormat = "%%D%% Days, %%H%% Hours, %%M%% Minutes, %%S%% Seconds.";
FinishMessage = "Tribes SHOULD be completed now!";
</script>
<script language="JavaScript" src="https://rhashemian.github.io/js/countdown.js"></script>