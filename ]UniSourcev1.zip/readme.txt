 Thank you for using the Unitorium source code!                                                                               The version of USCOP is v.1.1
     The only official way to get a copy of the source code is at http://sulpha-claim.000webhostapp.com
    Any other site claiming to be the official open-source version is fake, and may put malicious code into it
    If you find 
                                                                                
                        .#########                             #########        
                       ###########                           ###########        
                      ###########                           (##########         
                                                                                
                    ***********                            ***********          
                   (##########,                           ###########           
                  ,##########(                           ###########            
                                                                                
                                                                                
                                                                                
               ###########                            ###########               
              (##########.                           ##########(                
             /##########*                           ###########                 
                                                                                
                                                                                
                                                                                
          (###########                          ###########                     
          ############                        (###########                      
          ############.                     ############*                       
          ##############                .#############(                         
          ,#########################################                            
            #####################################                               
              ###############################.                                  
                 .#####################(                                        
                                                                                
